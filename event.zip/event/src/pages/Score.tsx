import Navbar from "@/components/Navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, TrendingUp, Award, Star } from "lucide-react";
import { Progress } from "@/components/ui/progress";

const Score = () => {
  const achievements = [
    { id: 1, name: "Event Explorer", description: "Attended 10 events", points: 500, icon: Trophy, unlocked: true },
    { id: 2, name: "City Navigator", description: "Visited 5 locations", points: 300, icon: Award, unlocked: true },
    { id: 3, name: "Social Butterfly", description: "Meet 20 people", points: 400, icon: Star, unlocked: false },
    { id: 4, name: "Early Bird", description: "Join 5 events first", points: 250, icon: TrendingUp, unlocked: false },
  ];

  const leaderboard = [
    { rank: 1, name: "Alex Johnson", score: 3500 },
    { rank: 2, name: "Sarah Miller", score: 3200 },
    { rank: 3, name: "You", score: 2450, isUser: true },
    { rank: 4, name: "Mike Davis", score: 2100 },
    { rank: 5, name: "Emma Wilson", score: 1800 },
  ];

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Your Score</h1>
          <p className="text-muted-foreground">
            Track your progress and achievements
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 mb-8">
          <Card className="border-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-yellow-500" />
                Total Score
              </CardTitle>
              <CardDescription>Your overall points</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-5xl font-bold mb-4">2,450</div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Next level</span>
                  <span className="font-medium">3,000</span>
                </div>
                <Progress value={81} className="h-2" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Rank
              </CardTitle>
              <CardDescription>Your position on the leaderboard</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-5xl font-bold mb-2">#3</div>
              <p className="text-sm text-muted-foreground">
                You're in the top 5% of all users!
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="border-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5 text-primary" />
                Achievements
              </CardTitle>
              <CardDescription>Unlock rewards by completing challenges</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {achievements.map((achievement) => (
                <div
                  key={achievement.id}
                  className={`flex items-center gap-4 p-4 rounded-lg border ${
                    achievement.unlocked ? "bg-gradient-to-r from-primary/5 to-accent/5" : "opacity-60"
                  }`}
                >
                  <div className={`h-12 w-12 rounded-full flex items-center justify-center ${
                    achievement.unlocked 
                      ? "bg-gradient-to-br from-primary to-accent" 
                      : "bg-muted"
                  }`}>
                    <achievement.icon className={`h-6 w-6 ${achievement.unlocked ? "text-white" : "text-muted-foreground"}`} />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold">{achievement.name}</h3>
                    <p className="text-sm text-muted-foreground">{achievement.description}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-primary">{achievement.points}</p>
                    <p className="text-xs text-muted-foreground">points</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5 text-yellow-500" />
                Leaderboard
              </CardTitle>
              <CardDescription>Top performers this month</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {leaderboard.map((entry) => (
                <div
                  key={entry.rank}
                  className={`flex items-center gap-4 p-3 rounded-lg ${
                    entry.isUser 
                      ? "bg-gradient-to-r from-primary/10 to-accent/10 border-2 border-primary/20" 
                      : "border"
                  }`}
                >
                  <div className={`h-8 w-8 rounded-full flex items-center justify-center font-bold ${
                    entry.rank === 1 
                      ? "bg-gradient-to-br from-yellow-400 to-yellow-600 text-white"
                      : entry.rank === 2
                      ? "bg-gradient-to-br from-gray-300 to-gray-500 text-white"
                      : entry.rank === 3
                      ? "bg-gradient-to-br from-orange-400 to-orange-600 text-white"
                      : "bg-muted"
                  }`}>
                    {entry.rank}
                  </div>
                  <span className={`flex-1 ${entry.isUser ? "font-bold" : ""}`}>
                    {entry.name}
                  </span>
                  <span className="font-bold text-primary">{entry.score.toLocaleString()}</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default Score;
