import Navbar from "@/components/Navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Navigation } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import type { LatLngExpression } from "leaflet";
import L from "leaflet";
import { useEffect } from "react";

// Import marker icon images
import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";

const Map = () => {
  // Fix Leaflet default icon issue
  useEffect(() => {
    delete (L.Icon.Default.prototype as any)._getIconUrl;
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: markerIcon2x,
      iconUrl: markerIcon,
      shadowUrl: markerShadow,
    });
  }, []);

  const locations = [
    { id: 1, name: "Carthage Amphitheatre", address: "Tunis, Tunisia", events: 3, lat: 36.8528, lng: 10.3233 },
    { id: 2, name: "Medina of Tunis", address: "Old Town, Tunis", events: 2, lat: 36.8190, lng: 10.1658 },
    { id: 3, name: "La Marsa Beach", address: "La Marsa, Tunisia", events: 1, lat: 36.8783, lng: 10.3247 },
    { id: 4, name: "Bardo Museum", address: "Le Bardo, Tunis", events: 1, lat: 36.8108, lng: 10.1347 },
  ];

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Event Map</h1>
          <p className="text-muted-foreground">
            Explore event locations near you
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="border-2 md:col-span-2 h-96 overflow-hidden">
            <MapContainer 
              center={[36.8065, 10.1815] as LatLngExpression} 
              zoom={11} 
              className="w-full h-full"
              style={{ height: "100%", width: "100%" }}
            >
              <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              {locations.map((location) => (
                <Marker key={location.id} position={[location.lat, location.lng] as LatLngExpression}>
                  <Popup>
                    <div className="text-sm">
                      <strong>{location.name}</strong>
                      <p className="text-xs text-muted-foreground">{location.address}</p>
                      <p className="text-xs font-medium mt-1">{location.events} events</p>
                    </div>
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          </Card>

          <Card className="border-2 md:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Navigation className="h-5 w-5 text-primary" />
                Nearby Locations
              </CardTitle>
              <CardDescription>Event venues in your area</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {locations.map((location) => (
                  <div
                    key={location.id}
                    className="flex items-center justify-between p-4 rounded-lg border hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                        <MapPin className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{location.name}</h3>
                        <p className="text-sm text-muted-foreground">{location.address}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{location.events} events</p>
                      <Button size="sm" variant="ghost" className="mt-1">
                        Directions
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default Map;
