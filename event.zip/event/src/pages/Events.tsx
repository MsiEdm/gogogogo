import Navbar from "@/components/Navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, Users, Clock } from "lucide-react";

const Events = () => {
  const events = [
    {
      id: 1,
      title: "Tech Conference 2025",
      description: "Join us for the biggest tech event of the year",
      date: "Tomorrow",
      time: "9:00 AM",
      location: "Convention Center",
      attendees: 150,
      category: "Technology",
    },
    {
      id: 2,
      title: "Community Meetup",
      description: "Connect with local community members",
      date: "Friday",
      time: "6:00 PM",
      location: "Central Park",
      attendees: 45,
      category: "Social",
    },
    {
      id: 3,
      title: "Art Exhibition",
      description: "Explore contemporary art from local artists",
      date: "Next Week",
      time: "2:00 PM",
      location: "City Gallery",
      attendees: 80,
      category: "Art",
    },
    {
      id: 4,
      title: "Food Festival",
      description: "Taste amazing dishes from around the world",
      date: "Next Weekend",
      time: "11:00 AM",
      location: "Downtown Square",
      attendees: 200,
      category: "Food",
    },
  ];

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Discover Events</h1>
          <p className="text-muted-foreground">
            Find and join amazing events in your area
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {events.map((event) => (
            <Card key={event.id} className="border-2 hover:shadow-lg transition-all hover:scale-[1.02]">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="mb-2">{event.title}</CardTitle>
                    <CardDescription>{event.description}</CardDescription>
                  </div>
                  <Badge variant="outline" className="ml-2">{event.category}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    <span>{event.date}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>{event.time}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span>{event.location}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Users className="h-4 w-4" />
                    <span>{event.attendees} attendees</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button className="flex-1 bg-gradient-to-r from-primary to-accent">
                    Join Event
                  </Button>
                  <Button variant="outline">Details</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Events;
